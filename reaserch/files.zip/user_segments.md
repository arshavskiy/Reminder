# User Segments - Reminder App

## Potential Target Segments

### Segment 1: Safety Inspectors (Primary for M.A.D Engineering)
**Description**: Field-based workers conducting regular safety inspections

| Attribute | Details |
|-----------|---------|
| **Role** | Safety inspector, facilities manager |
| **Team Size** | 1–10 people |
| **Pain Point** | Remembering daily/weekly checklists, compliance deadlines |
| **Tech Level** | Medium (comfortable with mobile, web) |
| **Current Tools** | Paper forms, email, Google Sheets, or custom systems |
| **Motivation** | Avoid violations, reduce risk, save time |
| **Budget** | Company pays, $10–50/user/month realistic |

**Key Questions to Test:**
- How often do they conduct inspections?
- Do they work solo or in teams?
- What happens if they miss a checkpoint?
- How do they currently track completion?

---

### Segment 2: Compliance Officers
**Description**: Oversee and monitor safety/regulatory compliance

| Attribute | Details |
|-----------|---------|
| **Role** | Compliance manager, audit lead |
| **Team Size** | 1–5 people |
| **Pain Point** | Tracking deadlines across multiple inspectors, audit readiness |
| **Tech Level** | Medium–High |
| **Current Tools** | Excel, Asana, Monday.com, or custom databases |
| **Motivation** | Reduce risk, audit preparation, accountability |
| **Budget** | Likely the buyer; $50–200/month for team |

**Key Questions to Test:**
- How many people do they oversee?
- What compliance standards apply? (OSHA, ISO, industry-specific?)
- How often are they audited?
- Do they need reporting/analytics?

---

### Segment 3: Facilities/Maintenance Teams
**Description**: Maintenance schedule reminders (not just safety)

| Attribute | Details |
|-----------|---------|
| **Role** | Maintenance coordinator, facilities manager |
| **Team Size** | 3–20 people |
| **Pain Point** | Remembering preventive maintenance, equipment checks |
| **Tech Level** | Low–Medium |
| **Current Tools** | Paper schedules, phone reminders, manual lists |
| **Motivation** | Reduce downtime, extend equipment life, compliance |
| **Budget** | Company-paid; $5–30/user/month |

**Key Questions to Test:**
- Are reminders for the same tasks or varied?
- Do they need to track who did what?
- Is mobile critical?

---

## Target Segment Priority (for you to rank)

**Rank these 1–3 based on your M.A.D Engineering context:**

1. Safety Inspectors ___
2. Compliance Officers ___
3. Facilities/Maintenance Teams ___

---

## Interview Targets

Once you've ranked segments, aim to interview:
- **2–3** from your primary segment
- **1–2** from secondary segments
- **1** from a completely different industry (to spot unexpected use cases)

**Where to find them:**
- Current M.A.D users (easiest!)
- LinkedIn (filter by role + company)
- Industry forums (safety engineering Reddit, OSHA communities)
- Local facilities management companies
