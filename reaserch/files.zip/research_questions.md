# Research Questions - Reminder App

## Core Research Objectives

### 1. User Identification
- **Q1**: Who exactly uses the reminder app? (Safety inspectors, facility managers, compliance officers, all of the above?)
- **Q2**: What's their skill level with technology?
- **Q3**: Are they using this individually or in teams?

### 2. Problem & Motivation
- **Q1**: What's the primary pain point we're solving? (Missing deadlines, forgotten safety checks, compliance violations, poor tracking?)
- **Q2**: How much does this problem cost them? (Time, money, risk, reputation?)
- **Q3**: Why does the current solution (if any) fail them?

### 3. Current Workflow
- **Q1**: How do they currently manage reminders? (Email, paper, spreadsheets, existing apps, nothing?)
- **Q2**: What's their reminder frequency? (Daily? Weekly? Ad-hoc?)
- **Q3**: Who else is involved in the reminder process?

### 4. Competitive Landscape
- **Q1**: What apps/tools are they currently using? (Todoist, Google Calendar, Slack, custom systems?)
- **Q2**: What do they like about existing solutions?
- **Q3**: What's missing that they want?

### 5. Adoption & Pricing
- **Q1**: Would they pay for a better reminder solution?
- **Q2**: How much? (One-time? Per-user/month? Freemium?)
- **Q3**: What would make them switch from their current solution?

---

## Hypotheses (To Test)

- [ ] Safety inspectors struggle to remember compliance checkpoints without automated reminders
- [ ] Existing tools don't track *completion* of safety tasks, only the reminder
- [ ] Teams need collaborative reminders (assign to person, track status)
- [ ] Mobile notifications are critical (reminders on-site, not just desktop)

---

## Success Criteria

After Phase 1 research, we'll know:
- ✓ Our target user persona (role, team size, tech comfort)
- ✓ The #1 problem we solve (ranked)
- ✓ 2–3 competitors we need to beat
- ✓ Rough pricing model (free, freemium, paid?)
