# Phase 1 Market Research - Reminder App

This folder contains templates and guides for conducting **Phase 1 Market Research** for your reminder web app.

## What's Inside

### 📋 research_questions.md
- Core research objectives (5 main areas)
- Hypotheses to test
- Success criteria for Phase 1

**Action**: Spend 30 minutes answering these questions for your app.

---

### 👥 user_segments.md
- 3 potential target user segments
- Detailed personas (role, pain points, budget, tools)
- Interview targets and where to find them

**Action**: Rank your priority segments. Aim to interview 5–8 users total.

---

### 🏆 competitive_analysis.md
- Direct competitors (Todoist, Microsoft To Do, TickTick)
- Indirect competitors (spreadsheets, calendar reminders)
- Market gaps and opportunities
- Hands-on testing checklist

**Action**: Spend 2 hours actually using 3–4 competing tools.

---

## Your Phase 1 Timeline (4 Weeks)

| Week | Task | Time |
|------|------|------|
| **Week 1** | Fill out research questions + rank user segments | 2 hours |
| **Week 1–2** | Test competitors (hands-on) | 3 hours |
| **Week 2–3** | Conduct 5–8 user interviews | 8–10 hours |
| **Week 3–4** | Synthesize findings + write summary | 4 hours |
| **Total** | | ~17 hours over 4 weeks |

---

## Quick Start (Today)

1. **Open `research_questions.md`**
2. **Answer the 5 core research questions** for your reminder app
3. **List your 3 biggest hypotheses** about users/market
4. **Commit to Git** (or save to your project folder)

```bash
# If you're adding this to your actual project:
cp -r /home/claude/reminder-research /path/to/your/reminder-app/research

# Or just track it separately if you prefer
```

---

## Next Phase (After Phase 1)

Once you complete Phase 1:
- Move to **Phase 2**: Competitive landscape research
- Then **Phase 3**: User interviews
- Then **Phase 4**: Quantitative survey validation
- Finally **Phase 5**: Synthesis + positioning

---

## Tips for Success

✅ **Do This:**
- Be honest about what you don't know
- Talk to real users (not just your friends)
- Write down everything; patterns emerge later
- Keep it simple — no fancy tools needed

❌ **Avoid This:**
- Assuming you know the answers (test them!)
- Only talking to people like you
- Overthinking the research process
- Waiting for "perfect" data before moving forward

---

## Resources

- **Interview template**: See `interview_guide.md` (Phase 2)
- **Survey template**: See `survey_questions.md` (Phase 3)
- **Synthesis template**: See `research_summary.md` (Phase 4)

---

## Questions?

Refer back to the main market research guide or reach out to your team for feedback on findings.
